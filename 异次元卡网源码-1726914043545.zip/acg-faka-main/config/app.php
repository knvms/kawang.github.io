<?php
declare (strict_types=1);

return [
    'version' => '1.1.7',
];